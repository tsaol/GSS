"""Azure provisioner for SkyPilot."""

from sky.provision.azure.instance import cleanup_ports
from sky.provision.azure.instance import open_ports
