// Dummy data for testing ReadTheDocs footer insertion
// This mimics RTD data for a project that uses both versions + languages
var READTHEDOCS_DATA = {
    project: "frc-docs",
    version: "latest",
    language: "en",
    proxied_api_host: "https://readthedocs.org",
};
